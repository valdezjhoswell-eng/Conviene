package com.rentablezone.app

import android.os.Bundle
import android.graphics.Color
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*

class ZonesActivity:AppCompatActivity(),OnMapReadyCallback{
    private lateinit var map:GoogleMap; private val points=mutableListOf<LatLng>(); private var poly:Polygon?=null; private val zones=mutableListOf<SavedZone>()
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_zones);zones.addAll(ZoneStore.load(this));val mv=findViewById<MapView>(R.id.map);mv.onCreate(b);mv.getMapAsync(this);findViewById<Spinner>(R.id.spZone).adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("🟢 Permitida","🟡 Precaución","🔴 Peligrosa"));findViewById<Button>(R.id.btnSave).setOnClickListener{if(points.size>=3){zones.add(SavedZone(findViewById<Spinner>(R.id.spZone).selectedItemPosition,points.toList()));ZoneStore.save(this,zones);toast("Zona guardada");points.clear();poly?.remove()}};findViewById<Button>(R.id.btnClear).setOnClickListener{points.clear();poly?.remove()}}
    override fun onMapReady(g:GoogleMap){map=g;map.uiSettings.isZoomControlsEnabled=true;map.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(-34.6037,-58.3816),11.5));map.setOnMapClickListener{ll->points.add(ll);redraw()};drawSaved()}
    private fun drawSaved(){zones.forEach{z->if(z.points.size>=3){val c=color(z.type);map.addPolygon(PolygonOptions().addAll(z.points).strokeColor(c).strokeWidth(4f).fillColor(Color.argb(50,Color.red(c),Color.green(c),Color.blue(c))) )}}
    private fun redraw(){poly?.remove();if(points.size<3)return;val c=color(findViewById<Spinner>(R.id.spZone).selectedItemPosition);poly=map.addPolygon(PolygonOptions().addAll(points).strokeColor(c).strokeWidth(5f).fillColor(Color.argb(55,Color.red(c),Color.green(c),Color.blue(c))))}
    private fun color(t:Int)=when(t){0->Color.rgb(30,170,90);1->Color.rgb(220,160,20);else->Color.rgb(210,55,70)}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    override fun onResume(){super.onResume();findViewById<MapView>(R.id.map)?.onResume()};override fun onPause(){findViewById<MapView>(R.id.map)?.onPause();super.onPause()};override fun onDestroy(){findViewById<MapView>(R.id.map)?.onDestroy();super.onDestroy()};override fun onLowMemory(){super.onLowMemory();findViewById<MapView>(R.id.map)?.onLowMemory()}
}
