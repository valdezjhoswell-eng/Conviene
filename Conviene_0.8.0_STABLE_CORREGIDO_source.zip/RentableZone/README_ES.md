# ¿Conviene? 0.1 — APK personal para Galaxy Tab A11

Esta versión es un proyecto Android para uso personal. La aplicación **no pulsa Aceptar/Rechazar ni controla Uber/Cabify**. Usa la captura de pantalla autorizada por Android para leer visualmente la oferta y coloca un panel flotante no táctil sobre la pantalla.

## Funciones incluidas
- Visor flotante no interactivo.
- Transparencia configurable.
- Captura MediaProjection.
- OCR de la pantalla con ML Kit.
- Detección básica de Uber/Cabify.
- Cálculo de $/km y $/hora.
- Filtros de km, minutos y rentabilidad.
- Filtro de cantidad de viajes (estructura preparada; depende de que el OCR encuentre el dato).
- Cabify: selector de tratamiento de efectivo.
- Mapa de zonas con colores verde/amarillo/rojo y dibujo de polígonos.

## Importante
El mapa usa Google Maps y necesita una API key. En `app/build.gradle.kts` reemplazar el placeholder `MAPS_API_KEY` por la clave, o adaptar el proyecto a otro proveedor de mapas.

## Compilar APK
Abrir la carpeta en Android Studio, sincronizar Gradle y ejecutar `Build > Build APK(s)`. El APK de debug aparecerá en `app/build/outputs/apk/debug/`.

## Permisos al instalar
1. Permitir "Mostrar sobre otras aplicaciones".
2. Iniciar el visor.
3. Aceptar el diálogo de Android para compartir/capturar pantalla.
4. Mantener la notificación del servicio activo mientras se trabaja.

## Criterio de distancia
La distancia para rentabilidad es **recogida + viaje con pasajero**. No se considera el regreso. Si la recogida aparece en metros (por ejemplo 828 m), se convierte a 0,828 km y se suma.

## Nota sobre OCR
Esta 0.1 es un prototipo: los formatos de Uber/Cabify pueden cambiar y el OCR puede confundirse con números o textos. Antes de usarlo en producción personal conviene probarlo con varias capturas reales y ajustar los patrones.
